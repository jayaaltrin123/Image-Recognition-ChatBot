import torch

model = torch.hub.load('ultralytics/yolov5', 'custom', path='/Users/g.jayaaltrin/yolov5/runs/train/exp7/weights/best.pt')

results = model('/Users/g.jayaaltrin/Downloads/train22.jpg') 

results.print()  

results.show()   

results.save()  
#/Users/g.jayaaltrin/Downloads/yolo1/electronics_components/train.py
#/usr/local/bin/python3 /Users/g.jayaaltrin/Downloads/yolo1/electronics_components/train.py;
#python3 train.py --img 640 --batch 16 --epochs 30 --data /Users/g.jayaaltrin/Downloads/yolo1/electronics_components/data.yaml --weights yolov5s.pt
